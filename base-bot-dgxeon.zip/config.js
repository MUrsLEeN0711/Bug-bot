//base by DGXeon (Xeon Bot Inc.)
//re-upload? recode? copy code? give credit ya :)
//YouTube: @DGXeon
//Instagram: unicorn_xeon13
//Telegram: @DGXeon13
//GitHub: @DGXeon13
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@DGXeon
//telegram channel: https://t.me/xeonbotincorporated

const global = {
    owner: [7039573852],
    botToken: " ",
    GROUP_ID: "-1002499093297",
    CHANNEL_ID: "-1002570284598",
    GROUP_LINK: "https://t.me/yt_mursleen_cheats_chat",
    CHANNEL_INVITE_LINK: "https://t.me/yt_mursleen_cheat_mod",
    WHATSAPP_LINK: "https://chat.whatsapp.com/JJ2WWkBEgd97KRexPaK0YA",
    YOUTUBE_LINK: "https://youtube.com/@yt-mursleen_cheats?si=T59_m5IqgU1acm5Z",
    INSTAGRAM_LINK: "https://www.instagram.com"
}

module.exports = global;